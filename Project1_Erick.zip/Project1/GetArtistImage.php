
<?php

include_once('ArtistController.php');

$suggestion = $_POST['artistimage'];

$controller = new ArtistController();
$artistImages = array();

$artistObjs = $controller->getArtists($suggestion);

foreach($artistsObjs as $artist)
{
	$artistImages[] = $artist->Image();
}

echo json_encode($artistImages);

?>