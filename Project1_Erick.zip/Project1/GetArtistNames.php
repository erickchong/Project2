
<?php

include_once('ArtistController.php');

$suggestion = $_POST['artistname'];

$controller = new ArtistController();
$artists = array();

$artistObjs = $controller->getArtists($suggestion);

foreach($artistsObjs as $artist)
{
	$artists[] = $artist->getName();
}

echo json_encode($artists);

?>