<?php

class Song
{
	private $artistName;
	private $songName;
	private $words;
	private $fullLyrics;

	public function __construct($artistName, $songName, $words = array(), $fullLyrics = "")
	{
		$this->artistName = $artistName;
		$this->songName = $songName;
		$this->words = $words;
		$this->fullLyrics = $fullLyrics;
	}

	// Returns the artist name, NOT the artist object
	public function getArtist()
	{
		return $this->artistName;
	}

	public function getName()
	{
		return $this->songName;
	}

	public function getWords()
	{
		return $this->words;
	}

	public function getFull()
	{
		return $this->fullLyrics;
	}
}


?>