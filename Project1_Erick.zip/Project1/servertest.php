<?php

include_once('PHPManager.php');


// Change this variable for different results
$ARTIST_NAME = "justin";


//error_reporting(0);

/*

$controller = new ArtistController();

$artists = $controller->getArtists('Big Bang');
$artistName = $artists[0]->getName();

$songs = $controller->getSongs($artistName);

$songWords = $songs[0]->getWords();


foreach ($songWords as $word)
{
	echo "$word \n";
}
*/
//echo "Test \n";

$manager = new PHPManager();

$artists = $manager->getArtistSuggestions($ARTIST_NAME);

// Print out the search result for a given $ARTIST_NAME
foreach ($artists as $artist)
{
	$artistName = $artist->getName();
	$artistImage = $artist->getImage();
	echo "$artistName <br/>";
	echo "$artistImage <br/> <br/>";

}

for ($i = 0; $i < 2; $i++)
{
	$artistName = $artists[$i]->getName();
	//echo "In outer for loop \n";

	//
	$cloudWords = $manager->getUpdatedCloud($artistName)->getWordObjects();
	//$numWords = count($cloudWords);
	//echo "Number of words in the cloud: $numWords \n";


	foreach($cloudWords as $word)
	{

		// Print out the words in the word cloud		
		$value = $word->getWordAsString();
		$frequency = $word->getFrequency();
		echo "word: $value, frequency: $frequency <br/>";
		//echo "$value".", $frequency \n"

	}
	echo "<br/> <br/>";
	//echo "$artistName \n";
}


?>
