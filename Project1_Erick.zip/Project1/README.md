# Word-Cloud

A lot of the PHP file functionality requires PHP cURL to work
