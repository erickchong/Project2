<?php
/**
 * @group testgroup
 *
 */

require_once 'Word.php';
use PHPUnit\Framework\TestCase;

class WordTest extends TestCase
{
	private $word;
	private $song;
	private $song2;

	protected function setUp()
	{
		$this->song = new Song("McCree", "Good Aim", array("its", "high", "noon"), "It's High Noon");
		$this->song2 = new Song("Genji", "Genji Is With You", array("dragon", "blade", "noon"), "Dragon Blade Noon");
		$this->word = new Word("noon", $this->song);
	}

	public function testGetWordAsString()
	{
		$this->assertEquals("noon", $this->word->getWordAsString());
	}

	public function testGetFrequency()
	{
		$this->assertEquals(1, $this->word->getFrequency());
	}


// Placeholder: getMap()

	// Test else statement?
	public function testUpdateFrequencyExists()
	{
		$oldVal = $this->word->getFrequency();
		$this->word->updateFrequency($this->song);
		$newVal = $this->word->getFrequency();

		$this->assertEquals($oldVal+1, $newVal);

	}

	public function testUpdateFrequencyNotExists()
	{
		$oldVal = $this->word->getFrequency();
		$this->word->updateFrequency($this->song2);
		$newVal = $this->word->getFrequency();

		$this->assertEquals($oldVal+1, $newVal);

	}


	public function testGetSongNames()
	{
		$this->assertEquals(array(array('name' => 'Good Aim', 'frequency' => 1)), $this->word->getSongNames());
	}

	/*
	public function testCompare()
	{
		$first = array('frequency' => 1);
		$second = array('frequency' => 2);

		$this->assertTrue($this->word->compare($first, $second));
		$this->assertFalse($this->word->compare($second, $first));
	}
	*/
	
}

?>