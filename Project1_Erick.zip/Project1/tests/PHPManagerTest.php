<?php
/**
 * @group testgroup
 *
 */

require_once 'PHPManager.php';
use PHPUnit\Framework\TestCase;

class PHPManagerTest extends TestCase
{
	private $phpManager;

	protected function setUp()
	{
		$this->phpManager = new PHPManager();
	}

	public function testGetArtistSuggestions()
	{
		$expectedArtists = 5;
		$artists = $this->phpManager->getArtistSuggestions("justin");

		$this->assertEquals($expectedArtists, count($artists)); // Contains 5 artists

		// Check to see if each 'artist' object contains an image and make array of artist names.
		$artistNames = array();

		foreach ($artists as $artist)
		{
			$this->assertNotNull($artist->getImage());
			$artistNames[] = $artist->getName();
		}

		// Check to see if the following artist names exist in the array (they are supposed to)
		$this->assertContains("Justin Bieber", $artistNames);
		$this->assertContains("Justin Timberlake", $artistNames);
		$this->assertContains("Justin Hurwitz", $artistNames);
		$this->assertContains("Justin Moore", $artistNames);
		$this->assertContains("Justin Quiles", $artistNames);
	}

	public function testGetUpdatedCloud()
	{
		$wordCloud = $this->phpManager->getUpdatedCloud("Justin Bieber");
		$words = $wordCloud->getWordObjects();

		$this->assertLessThanOrEqual(250, count($words));

		$wordCloud = $this->phpManager->getUpdatedCloud("Justin Timberlake");

		$this->assertLessThanOrEqual(250, count($words));
	}

	public function testGetNewCloud()
	{
		$wordCloud = $this->phpManager->getUpdatedCloud("Justin Bieber");
		$words = $wordCloud->getWordObjects();
		$wordCount = count($words);

		// Update again
		$wordCloud = $this->phpManager->getUpdatedCloud("Justin Timberlake");

		// New word cloud
		$wordCloud = $this->phpManager->getNewCloud("Justin Bieber");
		$words = $wordCloud->getWordObjects();

		// Check to see if it's the same word count as the first word cloud update
		$this->assertEquals($wordCount, count($words));
	}
}


?>