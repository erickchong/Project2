<?php

include_once('Song.php');

// Created word class to help determine word frequency
class Word
{
	// The actual word in string form
	private $wordString;
	// frequency is an integer
	private $frequency;

	// Map with value=song name & key=frequency
	private $songMap;


	// Takes in a string word and a song object
	public function __construct($wordString, $song)
	{
		$this->songMap = array();
		$this->wordString = $wordString;
		$this->frequency = 1;

		$this->songMap[$song->getName()] = array('song' => $song, 'frequency' => 1);
	}

	public function getWordAsString() {
		return $this->wordString;
	}

	// compare frequency function?

	public function getFrequency()
	{
		return $this->frequency;
	}

	public function getMap()
	{
		return $this->songMap;
	}

	// Updates frequency of the word in a given song object
	public function updateFrequency($song)
	{
		++$this->frequency;
		$songName = $song->getName();

		if (array_key_exists($songName, $this->songMap))
		{
			$this->songMap[$songName]['frequency']++;
		}

		else
		{
			$this->songMap[$songName] = array('song' => $song, 'frequency' => 1);
		}
	}


	public function getSongNames()
	{
		$songs = array();

		foreach ($this->songMap as $name => $song)
		{
			$songs[] = array('name' => $name, 'frequency' => $song['frequency']);
		}

		uasort($songs, array("Word", 'compare'));

		// Return sorted (by frequency) an array of songs
		return $songs;
	}
	

	private function compare($first, $second)
	{
		return ($first['frequency'] < $second['frequency']);
	}

}



?>