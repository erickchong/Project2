<?php
/**
 * @group testgroup
 *
 */

require_once 'Artist.php';
use PHPUnit\Framework\TestCase;

class ArtistTest extends TestCase
{
	private $artist;

	protected function setUp()
	{
		$this->artist = new Artist("Reol", "ImageURL");
	}

	public function testGetName()
	{
		$this->assertEquals("Reol", $this->artist->getName());
	}

	public function testGetImage()
	{
		$this->assertEquals("ImageURL", $this->artist->getImage());
	}
}


?>