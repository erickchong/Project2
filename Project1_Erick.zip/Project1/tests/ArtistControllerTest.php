<?php
/**
 * @group testgroup
 *
 */

require_once 'ArtistController.php';
use PHPUnit\Framework\TestCase;

class ArtistControllerTest extends TestCase
{
	private $artistController;

	protected function setUp()
	{
		$this->artistController = new ArtistController();
	}

	public function testGetArtists()
	{
		$expectedArtists = 5;
		$artists = $this->artistController->getArtists("justin");

		$this->assertEquals($expectedArtists, count($artists)); // Contains 5 artists

		// Check to see if each 'artist' object contains an image and make array of artist names.
		$artistNames = array();

		foreach ($artists as $artist)
		{
			$this->assertNotNull($artist->getImage());
			$artistNames[] = $artist->getName();
		}

		// Check to see if the following artist names exist in the array (they are supposed to)
		$this->assertContains("Justin Bieber", $artistNames);
		$this->assertContains("Justin Timberlake", $artistNames);
		$this->assertContains("Justin Hurwitz", $artistNames);
		$this->assertContains("Justin Moore", $artistNames);
		$this->assertContains("Justin Quiles", $artistNames);
	}

	public function testGetSongs()
	{
		$expectedSongs = 5;
		$songs = $this->artistController->getSongs("Justin Bieber");

		$this->assertLessThanOrEqual($expectedSongs, count($songs)); // Expect 5 or less songs

		// Every song should be by Justin Beiber because that's whose songs we're getting
		foreach ($songs as $song)
		{
			$this->assertEquals("Justin Bieber", $song->getArtist());
		}
	}
}


?>