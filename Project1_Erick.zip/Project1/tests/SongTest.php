<?php
/**
 * @group testgroup
 *
 */

require_once 'Song.php';
use PHPUnit\Framework\TestCase;

class SongTest extends TestCase
{
	private $song;

	protected function setUp()
	{
		$this->song = new Song("McCree", "Good Aim", array("its", "high", "noon"), "It's High Noon");
	}

	public function testGetArtist()
	{
		$this->assertEquals("McCree", $this->song->getArtist());
	}

	public function testGetName()
	{
		$this->assertEquals("Good Aim", $this->song->getName());
	}

	public function testGetWords()
	{
		$this->assertEquals(array("its", "high", "noon"), $this->song->getWords());
	}

	public function testGetFull()
	{
		$this->assertEquals("It's High Noon", $this->song->GetFull());
	}
}


?>