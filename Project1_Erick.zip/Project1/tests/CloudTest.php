<?php
/**
 * @group testgroup
 *
 */

require_once 'Cloud.php';
use PHPUnit\Framework\TestCase;

class CloudTest extends TestCase
{
	private $cloud;

	protected function setUp()
	{
		$artists = array("McCree", "Genji", "Soldier76");
		$mccreeSong = new Song("McCree", "Good Aim", array("its", "high", "noon"), "It's High Noon");
		$genjiSong = new Song("Genji", "Genji Is With You", array("dragon", "blade", "noon"), "Dragon Blade Noon");

		$wordObjects = array(new Word("noon", $mccreeSong), new Word("blade", $genjiSong));

		$this->cloud = new Cloud($artists, $wordObjects);
	}

	public function testGetWordObject()
	{
		$wordObject = $this->cloud->getWordObject("blade");

		// Check that we got the word object with string value of "blade"
		$this->assertEquals("blade", $wordObject->getWordAsString());

	}

	public function testGetWordObjects()
	{
		$wordObjects = $this->cloud->getWordObjects();
		$this->assertEquals(2, count($wordObjects));

		$this->assertEquals("noon", $wordObjects[0]->getWordAsString());
		$this->assertEquals("blade", $wordObjects[1]->getWordAsString());

	}

	public function testGetArtists()
	{
		$artists = $this->cloud->getArtists();
		$this->assertEquals(3, count($artists));
		$this->assertContains("McCree", $artists);
		$this->assertContains("Genji", $artists);
		$this->assertContains("Soldier76", $artists);

	}
}

?>