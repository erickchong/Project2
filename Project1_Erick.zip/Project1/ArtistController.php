<?php

require_once 'vendor/autoload.php';

include_once('Artist.php');
include_once('Song.php');
//include_once('lyricscore.php');


class ArtistController
{
	private $spotifyAPI;

	// Append this authenticator to the end of every musixmatch request
	private $authenticator = "&apikey=43ab7e181021a094b7b1f256b3d7f203";

	private $nonCommercialNotice = "******* This Lyrics is NOT for Commercial use *******";

	private $testFilter = array('yourself', 'love');

	private $filteredWords = array('a','about','above','after','again', 'know', 'like' ,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
								'against','all','am','an','and','any','are','arent', 'us', 'tell', 'let', 'oh', 'can', 'got', 'makes', 'just', 'get',
								'as','at','be','because','been','before','being',
								'below','between','both','but','by','cant','cannot',
								'could','couldnt','did','didnt','do','does','doesnt',
								'doing','dont','down','during','each','few','for','from','further',
								'had','hadnt','has','hasnt','have','havent','having','he','hed',
								'hell','hes','her','here','heres','hers','herself','him','himself','his',
								'how','hows','i','id','ill','im','ive','if','in','into','is','isnt','it',
								'its','itself','lets','me','more','most','mustnt','my','myself','no','nor',
								'not','of','off','on','once','only','or','other','ought','our','ours','ourselves',
								'out','over','own','same','shant','she','shed','shell','shes','should','shouldnt',
								'so','some','such','than','that','thats','the','their','theirs',
								'them','themselves','then','there','theres','these','they','theyd','theyll',
								'theyre','theyve','this','those','through','to','too','under','until','up','very',
								'was','wasnt','we','wed','well','were','weve','were','werent','what','whats',
								'when','whens','where','wheres','which','while','who','whos','whom','why',
								'whys','with','wont','would','wouldnt','you','youd','youll','youre',
								'youve','your','yours','yourself','yourselves');

	public function __construct()
	{
		$this->spotifyAPI = new SpotifyWebAPI\SpotifyWebAPI();
	}


	// Returns an array of Artist objects
	public function getArtists($artistName)
	{
		$response = $this->spotifyAPI->search($artistName, 'artist');
		$response = json_decode(json_encode($response), true);


		// $result contains the array of artists from the search results
		$result = $response['artists']['items'];

		$numArtists = count($result);

		// $artists is an array of Artist objects
		$artists = array();

		// If there are more than 3 artists, only get info of the first 3
		if ($numArtists > 5)
		{
			$numArtists = 5;
		}

		for ($i = 0; $i < $numArtists; $i++)
		{
			$artistImage = "";
			$fullArtistName = $result[$i]['name'];
			$smallestImageIndex = count($result[$i]['images']) - 1;

			// If the given artist doesn't have any images, don't get an image
			if ($smallestImageIndex != -1)
			{
				$artistImage = $result[$i]['images'][$smallestImageIndex]['url'];
			}

			$artists[] = new Artist($fullArtistName, $artistImage);
		}

		return $artists;

	}




	// Musixmatch api version of getSongs
	public function getSongs($artistName, $maxSongs = 5)
	{
		$result = array();

		// Need to change spaces to '-'
		$adaptedName = "&q_artist=" . str_replace(' ', '-', $artistName);

		// cURL request to get musixmatch artist_id for $artistName
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => 'http://api.musixmatch.com/ws/1.1/artist.search?page_size=5&format=json'. $adaptedName . $this->authenticator
			));

		$response = curl_exec($curl);
		curl_close($curl);

		$decode = json_decode($response, true);


		$artistID;

		if (count($decode['message']['body']['artist_list']) == 0)
		{
			$artistID = 0;
			echo "No artist found \n";
			return $result;
		}
		else
		{
			$artistID = $decode['message']['body']['artist_list'][0]['artist']['artist_id'];
			//echo "$artistID \n";
		}


		$urlArtistID = "&artist_id=" . $artistID;

		// cURL request for album ID's by $artistName
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => 'http://api.musixmatch.com/ws/1.1/artist.albums.get?g_album_name=1&format=json'. $urlArtistID . $this->authenticator
			));

		$response = curl_exec($curl);
		curl_close($curl);

		$decode = json_decode($response, true);


		$albums = $decode['message']['body']['album_list'];

		/*
		$numAlbums = count($albums);
		echo "Amount of albums: $numAlbums \n";
		*/

		foreach($albums as $album)
		{
			$albumID = $album['album']['album_id'];

			$urlAlbumID = "&album_id=" . $albumID;

			
			// cURL request for track ID's in a given $album
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_URL => 'http://api.musixmatch.com/ws/1.1/album.tracks.get?f_has_lyrics=1&page=1&page_size=2&format=json' . $urlAlbumID . $this->authenticator
				));

			$response = curl_exec($curl);
			curl_close($curl);

			$decode = json_decode($response, true);


			$tracks = $decode['message']['body']['track_list'];

			/*
			$numTracks = count($tracks);
			echo "Amount of tracks: $numTracks \n";
			*/

			
			foreach($tracks as $track)
			{
				$trackName = $track['track']['track_name'];
				$trackID = $track['track']['track_id'];

				$urlTrackID = "&track_id=" . $trackID;
				
				// cURL request for lyrics given a track_id
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_RETURNTRANSFER => 1,
					CURLOPT_URL => 'http://api.musixmatch.com/ws/1.1/track.lyrics.get?format=json' . $urlTrackID . $this->authenticator
					));

				$response = curl_exec($curl);
				curl_close($curl);

				$decode = json_decode($response, true);

				// Only 30% of lyrics because we are using free version
				$fullLyrics = $decode['message']['body']['lyrics']['lyrics_body'];
				$trimmedLyrics = str_replace($this->nonCommercialNotice, '', $fullLyrics);

				// Remove parantheses and anything in between
				$trimmedLyrics = preg_replace('@\([^\)]*\)$@', '', $trimmedLyrics);
				$trimmedLyrics = str_replace('.', '', $trimmedLyrics);
				$trimmedLyrics = str_replace(',', '', $trimmedLyrics);
				$trimmedLyrics = str_replace('?', '', $trimmedLyrics);
				$trimmedLyrics = str_replace("'", "", $trimmedLyrics);
				$trimmedLyrics = str_replace('!', '', $trimmedLyrics);
				$trimmedLyrics = str_replace('(', '', $trimmedLyrics);
				$trimmedLyrics = str_replace(')', '', $trimmedLyrics);
				$trimmedLyrics = str_replace('...', '', $trimmedLyrics);
				// Removes unncessary spaces and newlines are replaced with a single space
				$trimmedLyrics = trim(preg_replace('/\s+/', ' ', $trimmedLyrics));
				$trimmedLyrics = strtolower($trimmedLyrics);
/*
				echo "$trackName \n";
				echo "$trimmedLyrics \n";
*/

				// Remove all words we don't want in the word cloud
				foreach ($this->filteredWords as $word)
				{
					//echo "Word: $word \n";
					$trimmedLyrics = str_replace(' '.$word.' ', ' ', $trimmedLyrics);
					$trimmedLyrics = $this->removeFrontBack($word, $trimmedLyrics);
					//echo "$trimmedLyrics \n \n";
				}

				$wordsArray = preg_split('/\s+/', $trimmedLyrics);

				$song = new Song($artistName, $trackName, $wordsArray, $fullLyrics);
				$result[] = $song;

				if (count($result) >= $maxSongs)
				{
					return $result;
				}
			}
			
			

		}
		return $result;
	}


	// Keep an eye on this function for testing. May try to access incorrect bounds
	// Removes words that we don't want from front or back (special case)
	private function removeFrontBack($word, $lyrics)
	{
		$lyricsArray = str_split($lyrics);
		$strBuilder = "";

		// Remove from front
		for ($i = 0; $i < count($lyricsArray); $i++)
		{
			// If not a space, add to the string builder
			if ($lyricsArray[$i] != ' ') $strBuilder .= $lyricsArray[$i];
			
			// If we encounter a space and we didn't already exit the loop, exit now
			if ($lyricsArray[$i] == ' ')
			{
				break;
			}

			else if ($strBuilder == $word && $lyricsArray[$i+1] == ' ')
			{
				$lyrics = substr($lyrics, strlen($word)+1);
				break;
			}
		}


		// Reset string builder
		$strBuilder = "";

		for ($i = count($lyricsArray)-1; $i >= 0; $i--)
		{
			// If not a space, add to the string builder
			if ($lyricsArray[$i] != ' ') $strBuilder .= $lyricsArray[$i];
			
			// If we encounter a space and we didn't already exit the loop, exit now
			if ($lyricsArray[$i] == ' ')
			{
				break;
			}

			else if (strrev($strBuilder) == $word && $lyricsArray[$i-1] == ' ')
			{
				$lyrics = substr($lyrics, 0, strlen($lyrics)-strlen($word)-1);
				break;
			}
		}


		return $lyrics;

	}

}

	


?>
