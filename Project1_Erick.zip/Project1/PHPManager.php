<?php

include_once('ArtistController.php');
include_once('Song.php');
include_once('Word.php');
include_once('Cloud.php');
include_once('Artist.php');


class PHPManager
{

	private $artistController;

	// Only contains artist names
	private $artists;

	// Array of song objects
	private $songs;

	// Array of word objects
	private $words;
	private $cloud;

	public function __construct()
	{
		$this->artistController = new ArtistController();
		$this->artists = array();
		$this->songs = array();
		$this->words = array();
	}

	// Returns an array of Artist objects. Use getName() or getImage() on Artist objects
	public function getArtistSuggestions($input)
	{
		return $this->artistController->getArtists($input);
	}


	// Use this function when user clicks submit
	public function getNewCloud($artistName)
	{
		// Get rid of the current artist and song arrays
		$this->artists = null;
		$this->songs = null;
		$this->words = array();

		return $this->getUpdatedCloud($artistName);
	}


	// Use this function when user clicks add artist
	public function getUpdatedCloud($artistName)
	{
		$this->addArtist($artistName);

		// Call function to get any new words and update frequencies of current words from current songs
		$this->getWords();

		// Get the words with top 250 frequencies (array)
		$cloudWords = $this->words;

		if (count($cloudWords) > 250)
		{
			$cloudWords = array_slice($cloudWords, 0, 250);
		}

		$this->cloud = new Cloud($this->artists, $cloudWords);
		return $this->cloud;

	}

		// Only use within the PHPManager class
	private function addArtist($artistName)
	{
		$this->artists[] = $artistName;

		// getSongs returns an array of Song objects. Use getName(), getWords(), or getFull() on Song objects
		$this->songs = $this->artistController->getSongs($artistName);
	}

	// Get any new words and update frequencies of existing words from current songs
	private function getWords()
	{
		foreach($this->songs as $song)
		{
			// Get the array of the words used in the song
			$lyrics = $song->getWords();

			foreach($lyrics as $lyric)
			{
				$foundWord = false;

				foreach($this->words as $word)
				{
					// If we found a word, update its frequency
					if ($lyric == $word->getWordAsString())
					{
						$word->updateFrequency($song);
						$foundWord = true;
					}
				}

				if ($foundWord == false)
				{
					// If we did not find the word, make a new Word object
					$word = new Word($lyric, $song);
					$this->words[] = $word;
				}
			}

		}

		// Clear songs array. Another one gets made when we add an artist's songs
		$this->songs = null;
	}
}




?>