<?php

include_once 'Word.php';

class Cloud
{

	private $artists;
	private $wordObjects;

	public function __construct($artists, $cloudWords)
	{
		$this->artists = $artists;
		$this->wordObjects = $cloudWords;
	}

	// $word as in the string form of the word
	function getWordObject($word)
	{
		foreach ($this->wordObjects as $wordObject)
		{
			if ($wordObject->getWordAsString() == $word)
			{
				return $wordObject;
			}
		}
	}

	public function getWordObjects()
	{
		return $this->wordObjects;
	}

	public function getArtists()
	{
		return $this->artists;
	}


}

?>