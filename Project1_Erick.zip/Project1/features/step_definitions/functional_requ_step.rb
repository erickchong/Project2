Given(/^I want to see specific Artist$/) do
	visit'http://localhost/search.html'
end

When(/^I intput the artist into the search box$/) do
	fill_in('tags',:with => 'Justin')
end

Then(/^I will see the realted artist$/) do
	page.should have_content('WordCloud')
end

Given(/^I want to see where Search Button takes me$/) do
  	visit'http://localhost/search.html'
end

When(/^I intput the artist name into the search box$/) do
	fill_in('tags',:with => 'Justin')
end

Then(/^I will see the cloud page$/) do
  	expect(page).to have_current_path('localhost/cloud_page.html')
end

