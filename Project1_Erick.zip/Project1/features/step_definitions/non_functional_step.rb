Given(/^Given I want to genrate a word cloud$/) do
	visit'http://localhost/search.html'
end

When(/^When I intput the artist into the search box and click search$/) do
	fill_in('tags',:with => 'Justin')
	click_button(search)
end

Then(/^I will see the result word cloud$/) do
	page.should have_content('WordCloud')
end

