Given(/^I want to see all the component on search page$/) do
	visit'search.html'
end

Then(/^I will see the button, backgroud color, text color$/) do
	should have_content("buyBtn, button")
	should have_content("search, ui-widget")
	color = find('body').native.css_value('background-color')
   	expect(color).to eq('#e6e6e6')
end

Given(/^I want to see all the component$/) do
	visit'search.html'
end

When(/^put in Justin Bierber in to the search box and click search$/) do
	fill_in('tags',:with => 'Justin')
	click_button(search)
end

Then(/^I will see the word cloud title as Justin Bieber$/) do
	should have_content('Justin Bieber')
end



