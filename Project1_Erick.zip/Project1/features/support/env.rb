require 'rspec/expectations'

require 'capybara/cucumber'
require 'capybara/rspec'

Capybara.default_driver = :selenium


Capybara.default_selector = :css

World(RSpec::Matchers)

$wordcloud_url='http://localhost:3000/'

def ui_url(path)
  $wordcloud_url+path
end
