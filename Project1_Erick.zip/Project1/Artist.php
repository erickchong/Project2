<?php

class Artist
{
	private $artistName;
	private $artistImage;

	public function __construct($artistName, $artistImage)
	{
		$this->artistName = $artistName;
		$this->artistImage = $artistImage;
	}

	// Return the name of the artist
	public function getName()
	{
		return $this->artistName;
	}

	// Return the artist's image URL
	public function getImage()
	{
		return $this->artistImage;
	}

}


?>